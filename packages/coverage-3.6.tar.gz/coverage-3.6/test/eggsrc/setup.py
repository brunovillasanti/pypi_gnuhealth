from setuptools import setup

setup(
    name="covtestegg1",
    packages=['egg1'],
    zip_safe=True,
    install_requires=[],
    )
