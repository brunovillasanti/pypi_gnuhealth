# A python source file with exotic characters
# -*- coding: utf-8 -*-

upside_down = "ʎd˙ǝbɐɹǝʌoɔ"
surrogate = "db40,dd00: x󠄀"
