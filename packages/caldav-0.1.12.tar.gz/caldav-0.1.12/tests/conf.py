#!/usr/bin/env python
# -*- encoding: utf-8 -*-

principal_url = "http://sogo1:sogo1@sogo-demo.inverse.ca:80/SOGo/dav/sogo1/Calendar/"
principal_url_ssl = "https://sogo1:sogo1@sogo-demo.inverse.ca:443/SOGo/dav/sogo1/Calendar/"

proxy = "192.168.0.132:8080"
proxy_noport = "192.168.0.132"
