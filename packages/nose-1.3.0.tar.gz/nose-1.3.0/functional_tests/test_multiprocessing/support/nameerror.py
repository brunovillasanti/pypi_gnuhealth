# we purposefully raise a NameError at the top level here

undefined_variable

