import modernity

def test():
    pass
