Skip: mark tests as skipped
===========================

.. autoplugin :: nose.plugins.skip
   :plugin: Skip