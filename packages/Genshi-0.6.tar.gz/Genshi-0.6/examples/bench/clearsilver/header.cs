<div id="header">
  <h1><?cs var:title ?></h1>
</div>

<?cs def:greeting(name) ?>
  <p>Hello, <?cs var:name ?>!</p>
<?cs /def ?>
